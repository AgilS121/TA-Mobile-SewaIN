<h1>NOT FOUND</h1>
<?php /**PATH E:\xampp\htdocs\TA\API\resources\views/404.blade.php ENDPATH**/ ?>