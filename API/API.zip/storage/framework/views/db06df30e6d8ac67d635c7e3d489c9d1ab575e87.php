<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($errors); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<form method="POST">
    <?php echo csrf_field(); ?>
    <input type="text" name="id" value="<?php echo e($user[0]['id']); ?>">
    <input type="password" name="password" placeholder="New Password">
    <br><br>
    <input type="password" name="password_confirmation" placeholder="Confirm New Password">
    <br><br>
    <input type="submit">
</form>
<?php /**PATH E:\xampp\htdocs\TA\API\resources\views/resetPassword.blade.php ENDPATH**/ ?>